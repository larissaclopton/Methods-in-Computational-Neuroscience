%% PSET 5

% The data in Kinematics.mat consists of the joint angles of an animal performing
% a reach-to-grasp task. The animal is grasping a variety of different objects,
% which are to differing extents eliciting different joint trajectories. 

%% Part 1 - PCA analysis

% The Matlab function 'pca' can be used to reduce the dimensionality of the 
% space of joint angles. Structure the data in such a way that it can be used 
% with pca. Then, use pca to perform a principle components analysis, in which
% you will acquire the principal component coefficients, the representation 
% of your trajectories in principal component space, and the eigenvalues for
% your principal components.

% Normalize all of the eigenvalues and plot them in rank order. What percentage
% of the variance does the first PC explain? The first two PCs? The first three?
% How many PCs do you need to account for 90% of the variance in the kinematic 
% data?

clear all; close all;
load('Kinematics.mat');

% each trial represented by matrix with set of measurements across time (rows) 
% for angles of different joints (columns)
trials = getfield(Kinematics,'Trials');

% structure the data for pca
ntrials = length(trials);
formatted_data = trials{1};

for i = 2:ntrials
    formatted_data = cat(1,formatted_data,trials{i});
end

% obtain principal component coefficients, representation in principal 
% component space, and eigenvalues for principal components
[coeff,score,eigvals] = pca(formatted_data);

% normalize, sort, and plot the eigenvalues
eigvals = sort(eigvals/sum(eigvals),'descend');
figure; plot(eigvals); 
xlabel('Principal Component'); ylabel('Variance explained');
title('Sorted eigenvalues of principal components');

% obtain the variance explained for various sets of PCs
var_1pc = eigvals(1);
var_2pc = sum(eigvals(1:2));
var_3pc = sum(eigvals(1:3));
var_6pc = sum(eigvals(1:6));

display(var_1pc); display(var_2pc); display(var_3pc); display(var_6pc);

% The first PC explains 48.18% of the variance, the first two PCs explain
% 70.28% of the variance, and the first three PCs explain 77.45% of the variance.
% Six PCs are needed to account for approximately 90% of the variance.

%% Part 2 - Synthetic Trajectories

% In order to visualize the principle components, generate two synthetic 
% trajectories that consist of only the first and second PCs, respectively.
% This can be done by creating a sequence of multiples of the PCs, i.e. 
% multiply the PC by x:d:y, and recombining with the mean. To find an 
% appropriate range for scaling, use x = min(score) and y = max(score) for 
% each PC, which will show the full range of motion seen in the data.
% Convert the synthetic trajectories to a .mot file and visualize the PCs 
% using OpenSim. Describe what aspects of the joint trajectories are represented
% by each of the PCs.
 
mu = mean(formatted_data);

% obtain synthetic trajectory for the first PC
figure;
[H1,PCkin1,nb1,nj1] = PCplot(coeff, mu, 1, [-160 15], [min(score(:,1)) max(score(:,1))]);
[H2,PCkin2,nb2,nj2] = PCplot(coeff, mu, 2, [-160 15], [min(score(:,2)) max(score(:,2))]);

% The first principal component represents the motion of actually picking
% up the object, where the fingers curl around the object and the wrist
% arches back as the object is being lifted. The second principal component 
% represents the arching down of the wrist and curling of the hand as the 
% animal grabs the object in what appears to be a scooping motion.

%% Part 3 - Reconstruction with selected PCs

% Take the first trial from the data set and reconstruct the trajectory of 
% wrist flexion angle (wr_flexion_1) using reduced dimensionality: 1) the
% trajectory reconstruction using only the first PC, 2) the trajectory 
% reconstruction using the first 2 PCs and 3) the reconstruction using the 
% first 3 PCs, 4) the reconstruction using all the PCs. Compare each of these
% to the original trajectory in a new figure by plotting the measured trajectory
% and the three reconstructed trajectories of the selected joint angle.

% obtain wr_flexion_1 angle trajectory of first trial from data
figure; hold on;
data = trials{1}(:,3);
plot(data,'g','LineWidth',3);
xlabel('Time step'); ylabel('Joint Angle');
title('Trajectory (measured versus reconstructed)');

% reconstruct the trajectory with first 1, 2, and 3 PCs
for i = 1:3
    reconstructed = score(:,1:i)*coeff(:,1:i)';
    reconstructed = bsxfun(@plus,mu,reconstructed); % add the mean back in
    reconstructed = reconstructed(1:931,3);
    plot(reconstructed);
end

% reconstruct the trajectory with all PCs
reconstructed = score*coeff';
reconstructed = bsxfun(@plus,mu,reconstructed); % add the mean back in
reconstructed = reconstructed(1:931,3);
plot(reconstructed,'k');
legend('Measured', '1 PC', '2 PCs', '3 PCs', 'all PCs');

% We see that the reconstructed trajectory using only 1 principal component
% has some similarities to the measured trajectory but also some differences
% and thus doesn't represent it very well. After adding the second principal
% component, we see that the reconstructed trajectory more closely represents
% the measured trajectory, and with the third principal component even
% closer still. This suggests that the data can be fairly well characterized by
% just a few dimensions. With all principal components, the measured
% trajectory is reconstructed perfectly.

%% Part 4 - Projected trajectories

% Using the same sample trial, get the projection of the trajectory onto 
% each of the first three principle components. In a single subplot, plot
% the trajectories of the first three principle components over time, using
% a different color for each PC. In an adjacent subplot, show the trajectory
% through 3-dimensional PC space. Inspect some of the less informative PCs. 
% What do you notice about the amplitude and frequency content of their 
% projections as they decrease in eigenvalue (and thus explain less of the 
% variance of the set)?

colors = ['g','r','b']; % colors for plotting

% look at the first three PCs
% plot the projected trajectories
figure;
subplot(2,1,1); hold on;
projection = zeros(931,3);
for i = 1:3
    projection(:,i) = score(1:931,i);
    plot(projection(:,i),colors(i));
end
xlabel('Time step'); ylabel('Joint Angle');
title('Projected trajectories');
legend('PC 1', 'PC 2', 'PC 3');
% plot the trajectory in 3-dimensional PC space
subplot(2,1,2);
plot3(projection(:,1),projection(:,2),projection(:,3));
xlabel('PC 1'); ylabel('PC 2'); zlabel('PC 3');
title('Trajectory in 3D PC space');

% look at some of the less informative PCs (specifically 7-9)
% plot the projected trajectories
figure;
subplot(2,1,1); hold on;
projection = zeros(931,3);
for i = 1:3
    projection(:,i) = score(1:931,i+6);
    plot(projection(:,i),colors(i));
end
xlabel('Time step'); ylabel('Joint Angle');
title('Projected trajectories');
legend('PC 7', 'PC 8', 'PC 9');
% plot the trajectory in 3-dimensional PC space
subplot(2,1,2);
plot3(projection(:,1),projection(:,2),projection(:,3));
xlabel('PC 7'); ylabel('PC 8'); zlabel('PC 9');
title('Trajectory in 3D PC space');

% look at even less informative PCs (specifically 13-15)
% plot the projected trajectories
figure;
subplot(2,1,1); hold on;
projection = zeros(931,3);
for i = 1:3
    projection(:,i) = score(1:931,i+12);
    plot(projection(:,i),colors(i));
end
xlabel('Time step'); ylabel('Joint Angle');
title('Projected trajectories');
legend('PC 13', 'PC 14', 'PC 15');
% plot the trajectory in 3-dimensional PC space
subplot(2,1,2);
plot3(projection(:,1),projection(:,2),projection(:,3));
xlabel('PC 13'); ylabel('PC 14'); zlabel('PC 15');
title('Trajectory in 3D PC space');

% The projected trajectories of less informative PCs have much smaller
% amplitudes (scaled back by around a factor of 10 already for the 7th-9th
% principal component). In addition, the projected trajectories for the less
% informative PCs are not as smooth, meaning they have more fast, local
% changes. In the frequency domain (such as a Fourier transform), this would
% be represented by the presence of higher frequencies. As the principal
% components decrease in their respective eigenvalues and explain less
% variance of the set, their projected trajectories capture more fine and
% quickly changing movements in the grasping motion.
